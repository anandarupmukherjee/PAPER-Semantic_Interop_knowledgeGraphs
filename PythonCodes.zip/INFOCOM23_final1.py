import numpy as np
import pandas as pd
from statsmodels.tsa.seasonal import seasonal_decompose
from scipy.fft import fft
import networkx as nx
from scipy.signal import find_peaks
import os
import matplotlib.pyplot as plt
from sklearn.metrics.pairwise import cosine_similarity
import time
import skfuzzy as fuzz
from sklearn.metrics.pairwise import cosine_similarity


########################################
ss1 = pd.read_csv('wearable/hr.csv')
ss2 = pd.read_csv('wearable/temp.csv') # 14400
ss3 = pd.read_csv('wearable/ppg.csv')
ss4 = pd.read_csv('wearable/eda.csv')
ss5 = pd.read_csv('wearable/ecg.csv')
ss6 = pd.read_csv('wearable/eeg.csv')


# Function to perform seasonal decomposition
def perform_seasonal_decomposition(time_series, freq):
    df2=pd.DataFrame(time_series)
    dates = pd.date_range(start='01-01-1912 00:00:00', periods=df2.shape[0], freq=freq)
    df2.set_index(dates, inplace=True)
    time_series = df2
    
    decomposition = seasonal_decompose(time_series, model='additive')
    trend = decomposition.trend
    seasonality = decomposition.seasonal
    residual = decomposition.resid
    
    residual = np.array(residual)
    residual[np.isnan(residual)] = 0
    
    trend = np.array(trend)
    trend[np.isnan(trend)] = 0
    
    seasonality = np.array(seasonality)
    # print("done_seasonality")
    
    return trend, seasonality, residual




# Function to calculate peak-to-peak distances
def calculate_peak_to_peak_distances(time_series):
    peaks, _ = find_peaks(time_series)
    troughs, _ = find_peaks(-time_series)
    peak_to_peak_distances = np.diff(peaks)
    # print("done_p2pk")
    return peak_to_peak_distances



def calculate_peak_widths(time_series):
    peaks, _ = find_peaks(time_series)
    peak_widths, _ = find_peaks(time_series, width=15)  # Adjust the width parameter as per requirement
    peak_widths = np.diff(peak_widths)
    return peak_widths



# Function to calculate the top 10 FFT frequencies
def calculate_top_10_fft_frequencies(time_series):
    fft_values = np.abs(fft(time_series))
    sorted_indices = np.argsort(fft_values)[::-1]
    top_10_indices = sorted_indices[:20]
    top_10_fft_frequencies = top_10_indices / len(time_series)
    # print("done_fft")
    return top_10_fft_frequencies


# def calculate_signal_features(signal):
#     # Calculate signal energy
#     energy = np.sum(signal ** 2)
    
#     # Calculate signal power
#     power = energy / len(signal)
    
#     # Calculate signal mean, standard deviation, skewness, and kurtosis
#     mean = np.mean(signal)
#     std = np.std(signal)
#     skewness = np.mean(((signal - mean) / std) ** 3)
#     kurtosis = np.mean(((signal - mean) / std) ** 4) - 3
    
#     return energy, power, skewness, kurtosis


def calculate_signal_features(signal):
    max_value = max(signal)
    min_value = min(signal)
    amplitude_range = max_value - min_value
    
    return amplitude_range


# Function to generate features and create a graph for a given sensor category
def generate_graph_for_sensor_category(time_series, category):
    freq = 'H'
    # Perform seasonal decomposition
    trend, seasonality, residual = perform_seasonal_decomposition(time_series, freq)
    
    # Convert features to 1-D arrays
    seasonality = np.array(seasonality)
    trend = np.array(trend)
    residual = np.array(residual)
    
    # Calculate peak-to-peak distances
    peak_to_peak_distances = calculate_peak_widths(np.array(time_series))
    
    # Calculate the top 10 FFT frequencies
    top_10_fft_frequencies = calculate_top_10_fft_frequencies(np.array(time_series))
    
    #Calculate morphological features of the signal
    # morphological_features = calculate_signal_features(np.array(time_series))
    
    # Create a knowledge graph for the sensor category
    graph = nx.Graph()
    graph.add_node(category, value={"seasonality": seasonality,
                                        "trend": trend,
                                        "residual": residual,
                                        "fft": top_10_fft_frequencies,
                                        "peak_to_peak_distances": peak_to_peak_distances})
    # print(graph.nodes())
    return graph




# Function to generate features and create a graph for a given time series
def generate_graph_for_time_series(time_series):
    freq = 'H'
    # Perform seasonal decomposition
    trend, seasonality, residual = perform_seasonal_decomposition(time_series, freq)
    
    # Convert features to 1-D arrays
    seasonality = np.array(seasonality)
    trend = np.array(trend)
    residual = np.array(residual)
    
    # Calculate peak-to-peak distances
    peak_to_peak_distances = calculate_peak_widths(np.array(time_series))
    
    # Calculate the top 10 FFT frequencies
    top_10_fft_frequencies = calculate_top_10_fft_frequencies(np.array(time_series))
    
    #Calculate morphological features of the signal
    # morphological_features = calculate_signal_features(np.array(time_series))
    
    # Create a knowledge graph for the time series
    graph = nx.Graph()
    graph.add_node("TimeSeries", value={"seasonality": seasonality,
                                        "trend": trend,
                                        "residual": residual,
                                        "fft": top_10_fft_frequencies,
                                        "peak_to_peak_distances": peak_to_peak_distances})
    # print(graph.nodes())
    return graph






def cosine_similarity(feature1, feature2):
    # Convert the feature vectors to numpy arrays
    feature1 = np.array(feature1)
    feature2 = np.array(feature2)
    
    # Calculate the dot product of the two vectors
    dot_product = np.dot(feature1, feature2)
    
    # Calculate the magnitudes of the two vectors
    magnitude1 = np.linalg.norm(feature1)
    magnitude2 = np.linalg.norm(feature2)
    
    # Calculate the cosine similarity
    similarity = dot_product / (magnitude1 * magnitude2)
    
    return similarity


# def compare_features(feature1, feature2):
#     matches = 0

#     # Perform similarity comparison using an appropriate method (e.g., cosine similarity)
#     similarity = cosine_similarity(feature1, feature2)
    
#     # Set a threshold value for similarity to consider as a match
#     threshold = 0.8  # Adjust the threshold value as per requirement
    
#     if similarity >= threshold:
#         matches += 1
#     return matches


def compare_features(feature1, feature2, threshold=0.65):
    # Pad the shorter array with zeros to match the length of the longer array
    max_length = max(len(feature1), len(feature2))
    feature1_padded = np.pad(feature1, (0, max_length - len(feature1)))
    feature2_padded = np.pad(feature2, (0, max_length - len(feature2)))
    
    # Calculate cosine similarity
    dot_product = np.dot(feature1_padded, feature2_padded)
    norm_feature1 = np.linalg.norm(feature1_padded)
    norm_feature2 = np.linalg.norm(feature2_padded)
    
    if norm_feature1 == 0 or norm_feature2 == 0:
        return 0.0
    
    similarity = dot_product / (norm_feature1 * norm_feature2)
    
    # Check if similarity is above the threshold and return a binary decision
    if similarity >= threshold:
        return 1
    else:
        return 0




# Initialize the knowledge graph
knowledge_graph = nx.Graph()

ths=5000

# List of sensor categories and their corresponding dataframes
sensor_categories = ["HR", "TEMP", "PPG", "EDA", "ECG", "EEG"]
dataframes = [ss1.iloc[:ths], ss2.iloc[:ths], ss3.iloc[:ths], ss4.iloc[:ths],
              ss5.iloc[:ths], ss6.iloc[:ths]]

# sensor_categories = ["HR", "TEMP", "ECG"]
# dataframes = [ss1.iloc[:5000],ss2.iloc[:5000], ss5.iloc[:5000]]

# Create graphs for each sensor category and add them to the knowledge graph
for category, df in zip(sensor_categories, dataframes):
    time_series = df.iloc[:, 0].values
    
    graph = generate_graph_for_sensor_category(time_series, category)
    knowledge_graph = nx.compose(knowledge_graph, graph)






def classify_and_update(new_graph, knowledge_graph):
    # Generate the graph for the new time series
    max_match_count = 0
    classified_category = "Unknown"
    
    for category in knowledge_graph.nodes():
        if category == "Unknown":
            continue
        
        sensor_node = knowledge_graph.nodes[category]
        sensor_data = sensor_node["value"]
        
        new_node = new_graph.nodes["TimeSeries"]
        new_data = new_node["value"]
        
        # Soft voting based on feature similarity
        seasonality_similarity = compare_features(new_data["seasonality"], sensor_data["seasonality"])
        trend_similarity = compare_features(new_data["trend"], sensor_data["trend"])
        residual_similarity = compare_features(new_data["residual"], sensor_data["residual"])
        fft_similarity = compare_features(new_data["fft"], sensor_data["fft"])
        peak_to_peak_distances_similarity = compare_features(new_data["peak_to_peak_distances"], sensor_data["peak_to_peak_distances"])
        # morphological_similarity = compare_features(new_data["morphological"], sensor_data["morphological"])
        
        # Consider the overall match count based on the sum of similarities from each feature
        match_count = seasonality_similarity + trend_similarity + residual_similarity + fft_similarity + peak_to_peak_distances_similarity 
        # print(match_count)
        
        # print(seasonality_similarity, trend_similarity, residual_similarity, fft_similarity, peak_to_peak_distances_similarity)
        if match_count > max_match_count:
            max_match_count = match_count
            classified_category = category
            
    return classified_category

  



####################### EVALUATE #######################
dirx = 'wearable/hr.csv'
ssx = pd.read_csv(dirx)



# Lists to store the classified categories and their occurrences
classified_categories = []
occurrences = []

# Read data in chunks of 5000 rows and classify each chunk
chunk_size = 5000
start = 0
end = chunk_size

while start < len(ssx):
    # Read a chunk of data
    df_unknown = ssx.iloc[start:end]
    time_series_unknown = df_unknown.iloc[:, 0].values

    # Create a new graph for the chunk
    new_graph = generate_graph_for_time_series(time_series_unknown)

    # Classify and update the chunk
    classified_category = classify_and_update(new_graph, knowledge_graph)
    print("Classified Category for chunk", start, "to", end, ":", classified_category)

    # Store the classified category and update its occurrence count
    if classified_category in classified_categories:
        index = classified_categories.index(classified_category)
        occurrences[index] += 1
    else:
        classified_categories.append(classified_category)
        occurrences.append(1)

    # Move to the next chunk
    start += chunk_size
    end += chunk_size
    if end > len(ssx):
        end = len(ssx)

# Create a boxplot
plt.bar(classified_categories, occurrences)
plt.xlabel("Classified Category")
plt.ylabel("Occurrences")
plt.title(f"Occurrences for: {dirx}")
plt.grid()
plt.show()










